
# Exploritory Analysis of Trending YouTube Videos in the US

In this project, we will discover what categories affect the viewrship of the most trending YouTube videos in the US. What we can gain from analyzing these categories would be that we can improve recommending different types of videos to other people based on the majority opinion of what genres of videos are perceived as worthwhile to watch.


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
#Storing the csv files of the trending youtube videos from the US as a variable
USvideos_data = pd.read_csv("USvideos.csv")
USvideos_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>video_id</th>
      <th>trending_date</th>
      <th>title</th>
      <th>channel_title</th>
      <th>category_id</th>
      <th>publish_time</th>
      <th>tags</th>
      <th>views</th>
      <th>likes</th>
      <th>dislikes</th>
      <th>comment_count</th>
      <th>thumbnail_link</th>
      <th>comments_disabled</th>
      <th>ratings_disabled</th>
      <th>video_error_or_removed</th>
      <th>description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2kyS6SvSYSE</td>
      <td>17.14.11</td>
      <td>WE WANT TO TALK ABOUT OUR MARRIAGE</td>
      <td>CaseyNeistat</td>
      <td>22</td>
      <td>2017-11-13T17:13:01.000Z</td>
      <td>SHANtell martin</td>
      <td>748374</td>
      <td>57527</td>
      <td>2966</td>
      <td>15954</td>
      <td>https://i.ytimg.com/vi/2kyS6SvSYSE/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>SHANTELL'S CHANNEL - https://www.youtube.com/s...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1ZAPwfrtAFY</td>
      <td>17.14.11</td>
      <td>The Trump Presidency: Last Week Tonight with J...</td>
      <td>LastWeekTonight</td>
      <td>24</td>
      <td>2017-11-13T07:30:00.000Z</td>
      <td>last week tonight trump presidency|"last week ...</td>
      <td>2418783</td>
      <td>97185</td>
      <td>6146</td>
      <td>12703</td>
      <td>https://i.ytimg.com/vi/1ZAPwfrtAFY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>One year after the presidential election, John...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5qpjK5DgCt4</td>
      <td>17.14.11</td>
      <td>Racist Superman | Rudy Mancuso, King Bach &amp; Le...</td>
      <td>Rudy Mancuso</td>
      <td>23</td>
      <td>2017-11-12T19:05:24.000Z</td>
      <td>racist superman|"rudy"|"mancuso"|"king"|"bach"...</td>
      <td>3191434</td>
      <td>146033</td>
      <td>5339</td>
      <td>8181</td>
      <td>https://i.ytimg.com/vi/5qpjK5DgCt4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>WATCH MY PREVIOUS VIDEO ▶ \n\nSUBSCRIBE ► http...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>puqaWrEC7tY</td>
      <td>17.14.11</td>
      <td>Nickelback Lyrics: Real or Fake?</td>
      <td>Good Mythical Morning</td>
      <td>24</td>
      <td>2017-11-13T11:00:04.000Z</td>
      <td>rhett and link|"gmm"|"good mythical morning"|"...</td>
      <td>343168</td>
      <td>10172</td>
      <td>666</td>
      <td>2146</td>
      <td>https://i.ytimg.com/vi/puqaWrEC7tY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Today we find out if Link is a Nickelback amat...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>d380meD0W0M</td>
      <td>17.14.11</td>
      <td>I Dare You: GOING BALD!?</td>
      <td>nigahiga</td>
      <td>24</td>
      <td>2017-11-12T18:01:41.000Z</td>
      <td>ryan|"higa"|"higatv"|"nigahiga"|"i dare you"|"...</td>
      <td>2095731</td>
      <td>132235</td>
      <td>1989</td>
      <td>17518</td>
      <td>https://i.ytimg.com/vi/d380meD0W0M/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>I know it's been a while since we did this sho...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>gHZ1Qz0KiKM</td>
      <td>17.14.11</td>
      <td>2 Weeks with iPhone X</td>
      <td>iJustine</td>
      <td>28</td>
      <td>2017-11-13T19:07:23.000Z</td>
      <td>ijustine|"week with iPhone X"|"iphone x"|"appl...</td>
      <td>119180</td>
      <td>9763</td>
      <td>511</td>
      <td>1434</td>
      <td>https://i.ytimg.com/vi/gHZ1Qz0KiKM/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Using the iPhone for the past two weeks -- her...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>39idVpFF7NQ</td>
      <td>17.14.11</td>
      <td>Roy Moore &amp; Jeff Sessions Cold Open - SNL</td>
      <td>Saturday Night Live</td>
      <td>24</td>
      <td>2017-11-12T05:37:17.000Z</td>
      <td>SNL|"Saturday Night Live"|"SNL Season 43"|"Epi...</td>
      <td>2103417</td>
      <td>15993</td>
      <td>2445</td>
      <td>1970</td>
      <td>https://i.ytimg.com/vi/39idVpFF7NQ/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Embattled Alabama Senate candidate Roy Moore (...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>nc99ccSXST0</td>
      <td>17.14.11</td>
      <td>5 Ice Cream Gadgets put to the Test</td>
      <td>CrazyRussianHacker</td>
      <td>28</td>
      <td>2017-11-12T21:50:37.000Z</td>
      <td>5 Ice Cream Gadgets|"Ice Cream"|"Cream Sandwic...</td>
      <td>817732</td>
      <td>23663</td>
      <td>778</td>
      <td>3432</td>
      <td>https://i.ytimg.com/vi/nc99ccSXST0/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Ice Cream Pint Combination Lock - http://amzn....</td>
    </tr>
    <tr>
      <th>8</th>
      <td>jr9QtXwC9vc</td>
      <td>17.14.11</td>
      <td>The Greatest Showman | Official Trailer 2 [HD]...</td>
      <td>20th Century Fox</td>
      <td>1</td>
      <td>2017-11-13T14:00:23.000Z</td>
      <td>Trailer|"Hugh Jackman"|"Michelle Williams"|"Za...</td>
      <td>826059</td>
      <td>3543</td>
      <td>119</td>
      <td>340</td>
      <td>https://i.ytimg.com/vi/jr9QtXwC9vc/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Inspired by the imagination of P.T. Barnum, Th...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>TUmyygCMMGA</td>
      <td>17.14.11</td>
      <td>Why the rise of the robots won’t mean the end ...</td>
      <td>Vox</td>
      <td>25</td>
      <td>2017-11-13T13:45:16.000Z</td>
      <td>vox.com|"vox"|"explain"|"shift change"|"future...</td>
      <td>256426</td>
      <td>12654</td>
      <td>1363</td>
      <td>2368</td>
      <td>https://i.ytimg.com/vi/TUmyygCMMGA/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>For now, at least, we have better things to wo...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>9wRQljFNDW8</td>
      <td>17.14.11</td>
      <td>Dion Lewis' 103-Yd Kick Return TD vs. Denver! ...</td>
      <td>NFL</td>
      <td>17</td>
      <td>2017-11-13T02:05:26.000Z</td>
      <td>NFL|"Football"|"offense"|"defense"|"afc"|"nfc"...</td>
      <td>81377</td>
      <td>655</td>
      <td>25</td>
      <td>177</td>
      <td>https://i.ytimg.com/vi/9wRQljFNDW8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>New England Patriots returner Dion Lewis blast...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>VifQlJit6A0</td>
      <td>17.14.11</td>
      <td>(SPOILERS) 'Shiva Saves the Day' Talked About ...</td>
      <td>amc</td>
      <td>24</td>
      <td>2017-11-13T03:00:00.000Z</td>
      <td>The Walking Dead|"shiva"|"tiger"|"king ezekiel...</td>
      <td>104578</td>
      <td>1576</td>
      <td>303</td>
      <td>1279</td>
      <td>https://i.ytimg.com/vi/VifQlJit6A0/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Shiva arrives just in time as King Ezekiel att...</td>
    </tr>
    <tr>
      <th>12</th>
      <td>5E4ZBSInqUU</td>
      <td>17.14.11</td>
      <td>Marshmello - Blocks (Official Music Video)</td>
      <td>marshmello</td>
      <td>10</td>
      <td>2017-11-13T17:00:00.000Z</td>
      <td>marshmello|"blocks"|"marshmello blocks"|"block...</td>
      <td>687582</td>
      <td>114188</td>
      <td>1333</td>
      <td>8371</td>
      <td>https://i.ytimg.com/vi/5E4ZBSInqUU/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>WATCH SILENCE MUSIC VIDEO ▶ https://youtu.be/T...</td>
    </tr>
    <tr>
      <th>13</th>
      <td>GgVmn66oK_A</td>
      <td>17.14.11</td>
      <td>Which Countries Are About To Collapse?</td>
      <td>NowThis World</td>
      <td>25</td>
      <td>2017-11-12T14:00:00.000Z</td>
      <td>nowthis|"nowthis world"|"world news"|"nowthis ...</td>
      <td>544770</td>
      <td>7848</td>
      <td>1171</td>
      <td>3981</td>
      <td>https://i.ytimg.com/vi/GgVmn66oK_A/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>The world at large is improving, but some coun...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>TaTleo4cOs8</td>
      <td>17.14.11</td>
      <td>SHOPPING FOR NEW FISH!!!</td>
      <td>The king of DIY</td>
      <td>15</td>
      <td>2017-11-12T18:30:01.000Z</td>
      <td>shopping for new fish|"new fish"|"aquarium fis...</td>
      <td>207532</td>
      <td>7473</td>
      <td>246</td>
      <td>2120</td>
      <td>https://i.ytimg.com/vi/TaTleo4cOs8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Today we go shopping for new fish for some of ...</td>
    </tr>
    <tr>
      <th>15</th>
      <td>kgaO45SyaO4</td>
      <td>17.14.11</td>
      <td>The New SpotMini</td>
      <td>BostonDynamics</td>
      <td>28</td>
      <td>2017-11-13T20:09:58.000Z</td>
      <td>Robots|"Boston Dynamics"|"SpotMini"|"Legged Lo...</td>
      <td>75752</td>
      <td>9419</td>
      <td>52</td>
      <td>1230</td>
      <td>https://i.ytimg.com/vi/kgaO45SyaO4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>For more information . . . stay tuned.</td>
    </tr>
    <tr>
      <th>16</th>
      <td>ZAQs-ctOqXQ</td>
      <td>17.14.11</td>
      <td>One Change That Would Make Pacific Rim a Classic</td>
      <td>Cracked</td>
      <td>23</td>
      <td>2017-11-12T17:00:05.000Z</td>
      <td>pacific rim|"pacific rim 2"|"pacific rim seque...</td>
      <td>295639</td>
      <td>8011</td>
      <td>638</td>
      <td>1256</td>
      <td>https://i.ytimg.com/vi/ZAQs-ctOqXQ/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Pacific Rim was so good, we can’t believe they...</td>
    </tr>
    <tr>
      <th>17</th>
      <td>YVfyYrEmzgM</td>
      <td>17.14.11</td>
      <td>How does your body know you're full? - Hilary ...</td>
      <td>TED-Ed</td>
      <td>27</td>
      <td>2017-11-13T16:00:07.000Z</td>
      <td>TED|"TED-Ed"|"TED Education"|"TED Ed"|"Hilary ...</td>
      <td>78044</td>
      <td>5398</td>
      <td>53</td>
      <td>385</td>
      <td>https://i.ytimg.com/vi/YVfyYrEmzgM/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Check out our Patreon page: https://www.patreo...</td>
    </tr>
    <tr>
      <th>18</th>
      <td>eNSN6qet1kE</td>
      <td>17.14.11</td>
      <td>HomeMade Electric Airplane</td>
      <td>PeterSripol</td>
      <td>28</td>
      <td>2017-11-13T15:30:17.000Z</td>
      <td>ultralight|"airplane"|"homemade"|"DIY"|"hoverb...</td>
      <td>97007</td>
      <td>11963</td>
      <td>36</td>
      <td>2211</td>
      <td>https://i.ytimg.com/vi/eNSN6qet1kE/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>aaaannnd now to fly out of ground effect! The ...</td>
    </tr>
    <tr>
      <th>19</th>
      <td>B5HORANmzHw</td>
      <td>17.14.11</td>
      <td>Founding An Inbreeding-Free Space Colony</td>
      <td>SciShow</td>
      <td>27</td>
      <td>2017-11-12T22:00:01.000Z</td>
      <td>SciShow|"science"|"Hank"|"Green"|"education"|"...</td>
      <td>223871</td>
      <td>8421</td>
      <td>191</td>
      <td>1214</td>
      <td>https://i.ytimg.com/vi/B5HORANmzHw/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Thanks to 23AndMe for supporting SciShow. Thes...</td>
    </tr>
    <tr>
      <th>20</th>
      <td>vU14JY3x81A</td>
      <td>17.14.11</td>
      <td>How Can You Control Your Dreams?</td>
      <td>Life Noggin</td>
      <td>27</td>
      <td>2017-11-13T14:00:03.000Z</td>
      <td>life noggin|"life noggin youtube"|"youtube lif...</td>
      <td>115791</td>
      <td>9586</td>
      <td>75</td>
      <td>2800</td>
      <td>https://i.ytimg.com/vi/vU14JY3x81A/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>What if there was a way to control your dreams...</td>
    </tr>
    <tr>
      <th>21</th>
      <td>6VhU_T463sU</td>
      <td>17.14.11</td>
      <td>The Making of Hela's Headdress from Thor: Ragn...</td>
      <td>Tested</td>
      <td>28</td>
      <td>2017-11-12T15:00:01.000Z</td>
      <td>tested|"testedcom"|"designercon 2017"|"preview...</td>
      <td>224019</td>
      <td>3585</td>
      <td>138</td>
      <td>208</td>
      <td>https://i.ytimg.com/vi/6VhU_T463sU/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>At this year's DesignerCon, we meet up with Ir...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>_-aDHxoblr4</td>
      <td>17.14.11</td>
      <td>Is It Dangerous To Talk To A Camera While Driv...</td>
      <td>Tom Scott</td>
      <td>27</td>
      <td>2017-11-13T16:00:03.000Z</td>
      <td>tom scott|"tomscott"|"built for science"|"nati...</td>
      <td>144418</td>
      <td>11758</td>
      <td>89</td>
      <td>1014</td>
      <td>https://i.ytimg.com/vi/_-aDHxoblr4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>I'm visiting the University of Iowa's National...</td>
    </tr>
    <tr>
      <th>23</th>
      <td>JBZTZZAcFTw</td>
      <td>17.14.11</td>
      <td>What $4,800 Will Get You In NYC | Sweet Digs H...</td>
      <td>Refinery29</td>
      <td>26</td>
      <td>2017-11-12T16:00:01.000Z</td>
      <td>refinery29|"refinery 29"|"r29"|"r29 video"|"vi...</td>
      <td>145921</td>
      <td>1707</td>
      <td>578</td>
      <td>673</td>
      <td>https://i.ytimg.com/vi/JBZTZZAcFTw/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>On this episode of Sweet Digs, we tour Social ...</td>
    </tr>
    <tr>
      <th>24</th>
      <td>lZ68j2J_GOM</td>
      <td>17.14.11</td>
      <td>Using Other People's Showers</td>
      <td>Gus Johnson</td>
      <td>23</td>
      <td>2017-11-13T14:44:24.000Z</td>
      <td>using other peoples showers|"gus"|"gus shower"...</td>
      <td>33980</td>
      <td>4884</td>
      <td>52</td>
      <td>234</td>
      <td>https://i.ytimg.com/vi/lZ68j2J_GOM/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Why is it so hard to figure out other people's...</td>
    </tr>
    <tr>
      <th>25</th>
      <td>dRpNZV18N_g</td>
      <td>17.14.11</td>
      <td>SPAGHETTI BURRITO VS SPAGHETTI BURRITO</td>
      <td>HellthyJunkFood</td>
      <td>24</td>
      <td>2017-11-12T14:00:04.000Z</td>
      <td>spaghetti burrito|"diy burrito"|"spaghetti"|"b...</td>
      <td>223077</td>
      <td>8676</td>
      <td>193</td>
      <td>1392</td>
      <td>https://i.ytimg.com/vi/dRpNZV18N_g/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Visit http://www.Bongiovibrand.com\nand get 20...</td>
    </tr>
    <tr>
      <th>26</th>
      <td>fcVjitaM3LY</td>
      <td>17.14.11</td>
      <td>78557 and Proth Primes - Numberphile</td>
      <td>Numberphile</td>
      <td>28</td>
      <td>2017-11-13T12:13:36.000Z</td>
      <td>numberphile|"prime numbers"|"proth prime"</td>
      <td>80705</td>
      <td>4687</td>
      <td>41</td>
      <td>437</td>
      <td>https://i.ytimg.com/vi/fcVjitaM3LY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>James Grime is back and talking prime numbers....</td>
    </tr>
    <tr>
      <th>27</th>
      <td>qeWvgZLz9yU</td>
      <td>17.14.11</td>
      <td>A Smart... MUG?! - Take apart a Heated Thermos!</td>
      <td>JerryRigEverything</td>
      <td>26</td>
      <td>2017-11-13T16:00:03.000Z</td>
      <td>Smart mug|"Heated thermos"|"tech"|"gift idea"|...</td>
      <td>120727</td>
      <td>9033</td>
      <td>224</td>
      <td>1346</td>
      <td>https://i.ytimg.com/vi/qeWvgZLz9yU/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>YouTubes new channel!: https://www.youtube.com...</td>
    </tr>
    <tr>
      <th>28</th>
      <td>iIxy3JN3-jc</td>
      <td>17.14.11</td>
      <td>LeBron James admits he was ripping Phil Jackso...</td>
      <td>Cleveland Cavaliers on cleveland.com</td>
      <td>25</td>
      <td>2017-11-13T15:42:28.000Z</td>
      <td>auth-jvardon-auth</td>
      <td>27943</td>
      <td>156</td>
      <td>36</td>
      <td>83</td>
      <td>https://i.ytimg.com/vi/iIxy3JN3-jc/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>LeBron James gave another all-time press confe...</td>
    </tr>
    <tr>
      <th>29</th>
      <td>n30k5CwLhS4</td>
      <td>17.14.11</td>
      <td>Nick Andopolis: Drummer</td>
      <td>FaeryInLoveInc</td>
      <td>1</td>
      <td>2011-05-29T17:03:12.000Z</td>
      <td>freaks and geeks|"jason segel"|"judd apatow"|"...</td>
      <td>50867</td>
      <td>715</td>
      <td>238</td>
      <td>246</td>
      <td>https://i.ytimg.com/vi/n30k5CwLhS4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>The opening of Freaks and Geeks Episode 6, I'm...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>40919</th>
      <td>vDyYMcjf500</td>
      <td>18.14.06</td>
      <td>The History of Fortnite Battle Royale - Did Yo...</td>
      <td>DidYouKnowGaming?</td>
      <td>20</td>
      <td>2018-05-24T19:00:24.000Z</td>
      <td>fortnite|"fortnite pc"|"fortnite battle royale...</td>
      <td>324219</td>
      <td>7840</td>
      <td>1333</td>
      <td>1257</td>
      <td>https://i.ytimg.com/vi/vDyYMcjf500/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Thanks to Skillshare for sponsoring this video...</td>
    </tr>
    <tr>
      <th>40920</th>
      <td>3Q2j5ApzSqs</td>
      <td>18.14.06</td>
      <td>Christina Aguilera - Fall In Line (Official Vi...</td>
      <td>CAguileraVEVO</td>
      <td>10</td>
      <td>2018-05-23T17:00:01.000Z</td>
      <td>Christina Aguilera feat. Demi Lovato|"Fall In ...</td>
      <td>16777231</td>
      <td>518106</td>
      <td>14427</td>
      <td>26162</td>
      <td>https://i.ytimg.com/vi/3Q2j5ApzSqs/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Pre-order Christina Aguilera’s new album ‘Libe...</td>
    </tr>
    <tr>
      <th>40921</th>
      <td>GfxNGjfSKRY</td>
      <td>18.14.06</td>
      <td>James Bay - Delicate (Taylor Swift cover) in t...</td>
      <td>BBCRadio1VEVO</td>
      <td>10</td>
      <td>2018-05-24T17:00:17.000Z</td>
      <td>James Bay|"Taylor Swift"|"Delicate"|"BBC"|"Rad...</td>
      <td>832097</td>
      <td>28479</td>
      <td>543</td>
      <td>936</td>
      <td>https://i.ytimg.com/vi/GfxNGjfSKRY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>James Bay covers Taylor Swift's Delicate in th...</td>
    </tr>
    <tr>
      <th>40922</th>
      <td>amtC28yfYCM</td>
      <td>18.14.06</td>
      <td>Mindy Kaling Is Mad She Wasn't Invited to the ...</td>
      <td>The Tonight Show Starring Jimmy Fallon</td>
      <td>23</td>
      <td>2018-05-24T08:00:00.000Z</td>
      <td>The Tonight Show|"Jimmy Fallon"|"Mindy Kaling"...</td>
      <td>588133</td>
      <td>6583</td>
      <td>381</td>
      <td>486</td>
      <td>https://i.ytimg.com/vi/amtC28yfYCM/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Mindy Kaling chats with Jimmy about his though...</td>
    </tr>
    <tr>
      <th>40923</th>
      <td>9NC2saE5MbQ</td>
      <td>18.14.06</td>
      <td>Camels vs. Cactus!!!   جمل</td>
      <td>camelsandfriends</td>
      <td>15</td>
      <td>2018-05-23T13:33:03.000Z</td>
      <td>camels|"cactus"|"pets"|"livestock"|"animals"|"...</td>
      <td>5985284</td>
      <td>33243</td>
      <td>4899</td>
      <td>16703</td>
      <td>https://i.ytimg.com/vi/9NC2saE5MbQ/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Dromedary camels tear through prickly pear cac...</td>
    </tr>
    <tr>
      <th>40924</th>
      <td>XdNOI-q70q4</td>
      <td>18.14.06</td>
      <td>GIANT Bowl of Lucky Charms CHALLENGE (5,000+ C...</td>
      <td>Matt Stonie</td>
      <td>24</td>
      <td>2018-05-23T00:15:30.000Z</td>
      <td>Matt Stonie|"Megatoad"|"Competitive Eating"|"F...</td>
      <td>2025376</td>
      <td>50919</td>
      <td>2127</td>
      <td>8253</td>
      <td>https://i.ytimg.com/vi/XdNOI-q70q4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Download Fortnite!! https://pixly.go2cloud.org...</td>
    </tr>
    <tr>
      <th>40925</th>
      <td>QgOXIEhHU1Y</td>
      <td>18.14.06</td>
      <td>Diplo, French Montana &amp; Lil Pump ft. Zhavia - ...</td>
      <td>Diplo</td>
      <td>10</td>
      <td>2018-05-21T14:12:22.000Z</td>
      <td>Welcome to the party|"Diplo"|"Lil Pump"|"Frenc...</td>
      <td>40087764</td>
      <td>835657</td>
      <td>25283</td>
      <td>38305</td>
      <td>https://i.ytimg.com/vi/QgOXIEhHU1Y/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Official Video | Diplo, French Montana &amp; Lil P...</td>
    </tr>
    <tr>
      <th>40926</th>
      <td>SQsPvrev_bQ</td>
      <td>18.14.06</td>
      <td>435</td>
      <td>Tyler, The Creator</td>
      <td>27</td>
      <td>2018-05-22T15:20:56.000Z</td>
      <td>tyler the creator|"435"|"nice toenails"|"golf ...</td>
      <td>2252933</td>
      <td>129865</td>
      <td>1550</td>
      <td>6673</td>
      <td>https://i.ytimg.com/vi/SQsPvrev_bQ/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>a random song laying around from the flower bo...</td>
    </tr>
    <tr>
      <th>40927</th>
      <td>_1LdMWlNYS4</td>
      <td>18.14.06</td>
      <td>That Time It Rained for Two Million Years</td>
      <td>PBS Eons</td>
      <td>28</td>
      <td>2018-05-22T21:00:37.000Z</td>
      <td>dinosaurs|"dinos"|"paleo"|"paleontology"|"scis...</td>
      <td>1925345</td>
      <td>46673</td>
      <td>1765</td>
      <td>4973</td>
      <td>https://i.ytimg.com/vi/_1LdMWlNYS4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Check out our NEW POSTER: https://store.dftba....</td>
    </tr>
    <tr>
      <th>40928</th>
      <td>AFbu21AGSho</td>
      <td>18.14.06</td>
      <td>Watch a Hercules Beetle Metamorphose Before Yo...</td>
      <td>Nat Geo WILD</td>
      <td>15</td>
      <td>2018-05-22T12:00:00.000Z</td>
      <td>nat geo wild|"national geographic"|"wild"|"wil...</td>
      <td>1165339</td>
      <td>20248</td>
      <td>668</td>
      <td>2261</td>
      <td>https://i.ytimg.com/vi/AFbu21AGSho/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Watch this beetle go from larvae to giant. The...</td>
    </tr>
    <tr>
      <th>40929</th>
      <td>hHaUQh6Gx-Q</td>
      <td>18.14.06</td>
      <td>Mustard, Nick Jonas - Anywhere</td>
      <td>MustardVEVO</td>
      <td>10</td>
      <td>2018-05-22T12:00:02.000Z</td>
      <td>Mustard|"Nick"|"Jonas"|"Anywhere"|"10"|"Summer...</td>
      <td>2653229</td>
      <td>48889</td>
      <td>890</td>
      <td>1181</td>
      <td>https://i.ytimg.com/vi/hHaUQh6Gx-Q/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Anywhere Out Now! http://smarturl.it/AnywhereM...</td>
    </tr>
    <tr>
      <th>40930</th>
      <td>wI89nVn6LHk</td>
      <td>18.14.06</td>
      <td>Maddie Poppe Wins American Idol 2018 - Finale ...</td>
      <td>American Idol</td>
      <td>24</td>
      <td>2018-05-22T04:08:24.000Z</td>
      <td>ABC|"americanidol"|"idol"|"american idol"|"rya...</td>
      <td>2003345</td>
      <td>19895</td>
      <td>2831</td>
      <td>3481</td>
      <td>https://i.ytimg.com/vi/wI89nVn6LHk/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Maddie Poppe the crowd the American Idol 2018 ...</td>
    </tr>
    <tr>
      <th>40931</th>
      <td>oLDbO545aKQ</td>
      <td>18.14.06</td>
      <td>Terrible Magicians | Rudy Mancuso &amp; Juanpa Zurita</td>
      <td>Rudy Mancuso</td>
      <td>10</td>
      <td>2018-05-21T21:00:33.000Z</td>
      <td>terrible magicians|"rudy"|"mancuso"|"juanpa"|"...</td>
      <td>3825440</td>
      <td>196635</td>
      <td>4514</td>
      <td>11203</td>
      <td>https://i.ytimg.com/vi/oLDbO545aKQ/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>WATCH MORE ▶ https://youtu.be/Q9_WGkd_svIWATCH...</td>
    </tr>
    <tr>
      <th>40932</th>
      <td>tiF9SzzzX_o</td>
      <td>18.14.06</td>
      <td>The Voice 2018 Brynn Cartelli - Finale: Skyfall</td>
      <td>The Voice</td>
      <td>24</td>
      <td>2018-05-22T02:34:39.000Z</td>
      <td>the voice season 14|"the voice finale performa...</td>
      <td>1437051</td>
      <td>19930</td>
      <td>1794</td>
      <td>1671</td>
      <td>https://i.ytimg.com/vi/tiF9SzzzX_o/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Brynn Cartelli sings Adele's Skyfall during th...</td>
    </tr>
    <tr>
      <th>40933</th>
      <td>Gs26bZTRkdU</td>
      <td>18.14.06</td>
      <td>8 Survival Myths That Will Definitely Make Thi...</td>
      <td>SciShow</td>
      <td>27</td>
      <td>2018-05-20T21:00:00.000Z</td>
      <td>SciShow|"science"|"Hank"|"Green"|"education"|"...</td>
      <td>979732</td>
      <td>29038</td>
      <td>1121</td>
      <td>2584</td>
      <td>https://i.ytimg.com/vi/Gs26bZTRkdU/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>You might think you know how to survive if you...</td>
    </tr>
    <tr>
      <th>40934</th>
      <td>Qcj15vHJTtk</td>
      <td>18.14.06</td>
      <td>Royal Wedding - SNL</td>
      <td>Saturday Night Live</td>
      <td>24</td>
      <td>2018-05-20T04:58:51.000Z</td>
      <td>SNL|"Saturday Night Live"|"SNL Season 43"|"SNL...</td>
      <td>8607264</td>
      <td>66559</td>
      <td>14179</td>
      <td>8382</td>
      <td>https://i.ytimg.com/vi/Qcj15vHJTtk/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Footage from Prince Harry's (Mikey Day) weddin...</td>
    </tr>
    <tr>
      <th>40935</th>
      <td>2in8XqiElwc</td>
      <td>18.14.06</td>
      <td>Nicki Minaj - Chun-Li (Live on SNL / 2018)</td>
      <td>NickiMinajAtVEVO</td>
      <td>10</td>
      <td>2018-05-20T07:53:59.000Z</td>
      <td>Nicki Minaj new music|"Nicki Minaj Queen"|"Nic...</td>
      <td>4945185</td>
      <td>189265</td>
      <td>9406</td>
      <td>18683</td>
      <td>https://i.ytimg.com/vi/2in8XqiElwc/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Chun-Li (Live on SNL / 2018)Song Available Her...</td>
    </tr>
    <tr>
      <th>40936</th>
      <td>Xr2rgT9uEnA</td>
      <td>18.14.06</td>
      <td>LIE DETECTOR TEST WITH MY GIRLFRIEND!</td>
      <td>miniminter</td>
      <td>20</td>
      <td>2018-05-20T18:00:02.000Z</td>
      <td>miniminter|"mm7games"|"simon"|"random"|"lie de...</td>
      <td>3229540</td>
      <td>109945</td>
      <td>3062</td>
      <td>6774</td>
      <td>https://i.ytimg.com/vi/Xr2rgT9uEnA/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Talia: https://www.youtube.com/user/nataliahad...</td>
    </tr>
    <tr>
      <th>40937</th>
      <td>v7H_Or9Nr5I</td>
      <td>18.14.06</td>
      <td>Lucas the Spider - Giant Spider</td>
      <td>Lucas the Spider</td>
      <td>1</td>
      <td>2018-05-19T14:52:43.000Z</td>
      <td>LucastheSpider|"Animation"|"3D Animation"|"Cute"</td>
      <td>8300584</td>
      <td>266267</td>
      <td>4237</td>
      <td>14617</td>
      <td>https://i.ytimg.com/vi/v7H_Or9Nr5I/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Lucas is a tiny spider to some...giant arachni...</td>
    </tr>
    <tr>
      <th>40938</th>
      <td>n_W54baizX8</td>
      <td>18.14.06</td>
      <td>Daddy Yankee - Hielo (Video Oficial)</td>
      <td>Daddy Yankee</td>
      <td>10</td>
      <td>2018-05-18T14:00:04.000Z</td>
      <td>daddy yankee reggaeton|"daddy yankee youtube"|...</td>
      <td>41803845</td>
      <td>628861</td>
      <td>42833</td>
      <td>39363</td>
      <td>https://i.ytimg.com/vi/n_W54baizX8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Daddy Yankee - Hielo (Video Oficial)Spotify: h...</td>
    </tr>
    <tr>
      <th>40939</th>
      <td>pcJo0tIWybY</td>
      <td>18.14.06</td>
      <td>SZA - Garden (Say It Like Dat) (Official Video)</td>
      <td>SZAVEVO</td>
      <td>10</td>
      <td>2018-05-18T14:00:04.000Z</td>
      <td>Garden (Say It Like Dat)|"R&amp;B"|"SZA"|"Top Dawg...</td>
      <td>6004782</td>
      <td>210802</td>
      <td>4166</td>
      <td>15169</td>
      <td>https://i.ytimg.com/vi/pcJo0tIWybY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>SZA's CTRL available on:Apple Music - http://s...</td>
    </tr>
    <tr>
      <th>40940</th>
      <td>_QWZvU7VCn8</td>
      <td>18.14.06</td>
      <td>Brad Pitt Bid $120k For A Night With Emilia Cl...</td>
      <td>The Graham Norton Show</td>
      <td>24</td>
      <td>2018-05-18T17:13:08.000Z</td>
      <td>Graham Norton|"Graham Norton Show Official"|"E...</td>
      <td>5564576</td>
      <td>46351</td>
      <td>2295</td>
      <td>2861</td>
      <td>https://i.ytimg.com/vi/_QWZvU7VCn8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Check out all that Emilia Clarke merch... Subs...</td>
    </tr>
    <tr>
      <th>40941</th>
      <td>7UoP9ABJXGE</td>
      <td>18.14.06</td>
      <td>Dan + Shay - Speechless (Wedding Video)</td>
      <td>Dan And Shay</td>
      <td>10</td>
      <td>2018-05-18T04:04:58.000Z</td>
      <td>wedding video|"heartfelt wedding video"|"emoti...</td>
      <td>5534278</td>
      <td>45128</td>
      <td>1591</td>
      <td>806</td>
      <td>https://i.ytimg.com/vi/7UoP9ABJXGE/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Stream + Download:https://wmna.sh/speechlessht...</td>
    </tr>
    <tr>
      <th>40942</th>
      <td>ju_inUnrLc4</td>
      <td>18.14.06</td>
      <td>Fifth Harmony - Don't Say You Love Me</td>
      <td>FifthHarmonyVEVO</td>
      <td>10</td>
      <td>2018-05-18T07:00:08.000Z</td>
      <td>fifth hamony|"harmonizers"|"lauren"|"ally"|"no...</td>
      <td>23502572</td>
      <td>676467</td>
      <td>15993</td>
      <td>52432</td>
      <td>https://i.ytimg.com/vi/ju_inUnrLc4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Fifth Harmony available at iTunes http://smart...</td>
    </tr>
    <tr>
      <th>40943</th>
      <td>1PhPYr_9zRY</td>
      <td>18.14.06</td>
      <td>BTS Plays With Puppies While Answering Fan Que...</td>
      <td>BuzzFeed Celeb</td>
      <td>22</td>
      <td>2018-05-18T16:39:29.000Z</td>
      <td>BuzzFeed|"BuzzFeedVideo"|"Puppy Interview"|"pu...</td>
      <td>8259128</td>
      <td>645888</td>
      <td>4052</td>
      <td>62610</td>
      <td>https://i.ytimg.com/vi/1PhPYr_9zRY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>BTS with the PPS, the puppies. These adorable ...</td>
    </tr>
    <tr>
      <th>40944</th>
      <td>BZt0qjTWNhw</td>
      <td>18.14.06</td>
      <td>The Cat Who Caught the Laser</td>
      <td>AaronsAnimals</td>
      <td>15</td>
      <td>2018-05-18T13:00:04.000Z</td>
      <td>aarons animals|"aarons"|"animals"|"cat"|"cats"...</td>
      <td>1685609</td>
      <td>38160</td>
      <td>1385</td>
      <td>2657</td>
      <td>https://i.ytimg.com/vi/BZt0qjTWNhw/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>The Cat Who Caught the Laser - Aaron's Animals</td>
    </tr>
    <tr>
      <th>40945</th>
      <td>1h7KV2sjUWY</td>
      <td>18.14.06</td>
      <td>True Facts : Ant Mutualism</td>
      <td>zefrank1</td>
      <td>22</td>
      <td>2018-05-18T01:00:06.000Z</td>
      <td>[none]</td>
      <td>1064798</td>
      <td>60008</td>
      <td>382</td>
      <td>3936</td>
      <td>https://i.ytimg.com/vi/1h7KV2sjUWY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>40946</th>
      <td>D6Oy4LfoqsU</td>
      <td>18.14.06</td>
      <td>I GAVE SAFIYA NYGAARD A PERFECT HAIR MAKEOVER ...</td>
      <td>Brad Mondo</td>
      <td>24</td>
      <td>2018-05-18T17:34:22.000Z</td>
      <td>I gave safiya nygaard a perfect hair makeover ...</td>
      <td>1066451</td>
      <td>48068</td>
      <td>1032</td>
      <td>3992</td>
      <td>https://i.ytimg.com/vi/D6Oy4LfoqsU/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>I had so much fun transforming Safiyas hair in...</td>
    </tr>
    <tr>
      <th>40947</th>
      <td>oV0zkMe1K8s</td>
      <td>18.14.06</td>
      <td>How Black Panther Should Have Ended</td>
      <td>How It Should Have Ended</td>
      <td>1</td>
      <td>2018-05-17T17:00:04.000Z</td>
      <td>Black Panther|"HISHE"|"Marvel"|"Infinity War"|...</td>
      <td>5660813</td>
      <td>192957</td>
      <td>2846</td>
      <td>13088</td>
      <td>https://i.ytimg.com/vi/oV0zkMe1K8s/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>How Black Panther Should Have EndedWatch More ...</td>
    </tr>
    <tr>
      <th>40948</th>
      <td>ooyjaVdt-jA</td>
      <td>18.14.06</td>
      <td>Official Call of Duty®: Black Ops 4 — Multipla...</td>
      <td>Call of Duty</td>
      <td>20</td>
      <td>2018-05-17T17:09:38.000Z</td>
      <td>call of duty|"cod"|"activision"|"Black Ops 4"</td>
      <td>10306119</td>
      <td>357079</td>
      <td>212976</td>
      <td>144795</td>
      <td>https://i.ytimg.com/vi/ooyjaVdt-jA/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Call of Duty: Black Ops 4 Multiplayer raises t...</td>
    </tr>
  </tbody>
</table>
<p>40949 rows × 16 columns</p>
</div>




```python
Videos_In_US = USvideos_data.drop_duplicates(subset = "title", keep = "first")
```


```python
#Organizing the most trending US Videos by views
Videos_In_US.sort_values(by = "views", ascending = False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>video_id</th>
      <th>trending_date</th>
      <th>title</th>
      <th>channel_title</th>
      <th>category_id</th>
      <th>publish_time</th>
      <th>tags</th>
      <th>views</th>
      <th>likes</th>
      <th>dislikes</th>
      <th>comment_count</th>
      <th>thumbnail_link</th>
      <th>comments_disabled</th>
      <th>ratings_disabled</th>
      <th>video_error_or_removed</th>
      <th>description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>23824</th>
      <td>#NAME?</td>
      <td>18.15.03</td>
      <td>Maluma - El Préstamo (Official Video)</td>
      <td>MalumaVEVO</td>
      <td>10</td>
      <td>2018-03-09T11:00:01.000Z</td>
      <td>Maluma Music|"Maluma Official Video"|"Maluma V...</td>
      <td>48431654</td>
      <td>609101</td>
      <td>52259</td>
      <td>29172</td>
      <td>https://i.ytimg.com/vi/-BQJo3vK8O8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Maluma - El Prestamo (Official Music Video)\nE...</td>
    </tr>
    <tr>
      <th>35550</th>
      <td>7C2z4GqqS5E</td>
      <td>18.19.05</td>
      <td>BTS (방탄소년단) 'FAKE LOVE' Official MV</td>
      <td>ibighit</td>
      <td>10</td>
      <td>2018-05-18T09:00:02.000Z</td>
      <td>BIGHIT|"빅히트"|"방탄소년단"|"BTS"|"BANGTAN"|"방탄"</td>
      <td>39349927</td>
      <td>3880071</td>
      <td>72707</td>
      <td>692305</td>
      <td>https://i.ytimg.com/vi/7C2z4GqqS5E/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>BTS (방탄소년단) 'FAKE LOVE' Official MVDirector : ...</td>
    </tr>
    <tr>
      <th>28605</th>
      <td>i0p1bmr0EmE</td>
      <td>18.14.04</td>
      <td>TWICE What is Love? M/V</td>
      <td>jypentertainment</td>
      <td>10</td>
      <td>2018-04-09T08:59:51.000Z</td>
      <td>TWICE What is Love|"TWICE What is Love?"|"TWIC...</td>
      <td>38873543</td>
      <td>1111592</td>
      <td>96407</td>
      <td>206632</td>
      <td>https://i.ytimg.com/vi/i0p1bmr0EmE/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>TWICE(트와이스) What is Love? M/V\n\nSpotify https...</td>
    </tr>
    <tr>
      <th>3200</th>
      <td>6ZfuNTqbHE8</td>
      <td>17.30.11</td>
      <td>Marvel Studios' Avengers: Infinity War Officia...</td>
      <td>Marvel Entertainment</td>
      <td>24</td>
      <td>2017-11-29T13:26:24.000Z</td>
      <td>marvel|"comics"|"comic books"|"nerdy"|"geeky"|...</td>
      <td>37736281</td>
      <td>1735895</td>
      <td>21969</td>
      <td>241237</td>
      <td>https://i.ytimg.com/vi/6ZfuNTqbHE8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>There was an idea… Avengers: Infinity War. In ...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>2Vv-BfVoq4g</td>
      <td>17.14.11</td>
      <td>Ed Sheeran - Perfect (Official Music Video)</td>
      <td>Ed Sheeran</td>
      <td>10</td>
      <td>2017-11-09T11:04:14.000Z</td>
      <td>edsheeran|"ed sheeran"|"acoustic"|"live"|"cove...</td>
      <td>33523622</td>
      <td>1634124</td>
      <td>21082</td>
      <td>85067</td>
      <td>https://i.ytimg.com/vi/2Vv-BfVoq4g/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>🎧: https://ad.gt/yt-perfect\n💰: https://atlant...</td>
    </tr>
    <tr>
      <th>33351</th>
      <td>VYOjWnS4cMY</td>
      <td>18.08.05</td>
      <td>Childish Gambino - This Is America (Official V...</td>
      <td>ChildishGambinoVEVO</td>
      <td>10</td>
      <td>2018-05-06T04:00:07.000Z</td>
      <td>Childish Gambino|"Rap"|"This Is America"|"mcDJ...</td>
      <td>31648454</td>
      <td>1405355</td>
      <td>51547</td>
      <td>149473</td>
      <td>https://i.ytimg.com/vi/VYOjWnS4cMY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>“This is America” by Childish Gambino http://s...</td>
    </tr>
    <tr>
      <th>30750</th>
      <td>u9Mv98Gr5pY</td>
      <td>18.25.04</td>
      <td>VENOM - Official Trailer (HD)</td>
      <td>Sony Pictures Entertainment</td>
      <td>24</td>
      <td>2018-04-24T03:45:03.000Z</td>
      <td>Venom|"Venom Movie"|"Venom (2018)"|"Marvel"|"M...</td>
      <td>27973210</td>
      <td>850362</td>
      <td>26541</td>
      <td>96767</td>
      <td>https://i.ytimg.com/vi/u9Mv98Gr5pY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>We Are #Venom. 10.5.18\n\nOne of Marvel's most...</td>
    </tr>
    <tr>
      <th>4600</th>
      <td>FlsCjmMhFmw</td>
      <td>17.07.12</td>
      <td>YouTube Rewind: The Shape of 2017 | #YouTubeRe...</td>
      <td>YouTube Spotlight</td>
      <td>24</td>
      <td>2017-12-06T17:58:51.000Z</td>
      <td>Rewind|"Rewind 2017"|"youtube rewind 2017"|"#Y...</td>
      <td>24782158</td>
      <td>1149185</td>
      <td>483924</td>
      <td>462103</td>
      <td>https://i.ytimg.com/vi/FlsCjmMhFmw/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>YouTube Rewind 2017. Celebrating the videos, p...</td>
    </tr>
    <tr>
      <th>28624</th>
      <td>U9BwWKXjVaI</td>
      <td>18.14.04</td>
      <td>Drake - Nice For What</td>
      <td>DrakeVEVO</td>
      <td>10</td>
      <td>2018-04-07T02:46:31.000Z</td>
      <td>Drake|"Nice"|"For"|"What"|"Young"|"Money"|"Hip...</td>
      <td>24421448</td>
      <td>641546</td>
      <td>16517</td>
      <td>42949</td>
      <td>https://i.ytimg.com/vi/U9BwWKXjVaI/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Music video by Drake performing Nice For What....</td>
    </tr>
    <tr>
      <th>38161</th>
      <td>1J76wN0TPI4</td>
      <td>18.01.06</td>
      <td>Sanju | Official Trailer | Ranbir Kapoor | Raj...</td>
      <td>FoxStarHindi</td>
      <td>24</td>
      <td>2018-05-30T07:51:32.000Z</td>
      <td>Sanju|"Official Trailer"|"sanju official trail...</td>
      <td>23758250</td>
      <td>587326</td>
      <td>18799</td>
      <td>43728</td>
      <td>https://i.ytimg.com/vi/1J76wN0TPI4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Few lives in our times are as dramatic and eni...</td>
    </tr>
    <tr>
      <th>40340</th>
      <td>MAjY8mCTXWk</td>
      <td>18.11.06</td>
      <td>周杰倫 Jay Chou【不愛我就拉倒 If You Don't Love Me, It's...</td>
      <td>杰威爾音樂 JVR Music</td>
      <td>10</td>
      <td>2018-05-14T15:59:47.000Z</td>
      <td>周杰倫|"Jay"|"Chou"|"周董"|"周杰伦"|"周傑倫"|"杰威尔"|"周周"|"...</td>
      <td>21957640</td>
      <td>140214</td>
      <td>10716</td>
      <td>15418</td>
      <td>https://i.ytimg.com/vi/MAjY8mCTXWk/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>MV點閱率破華語歌曲紀錄，首日點閱突破200萬，三週已狂飆2000萬！不僅在華語地區蟬聯發燒...</td>
    </tr>
    <tr>
      <th>16181</th>
      <td>BhIEIO0vaBE</td>
      <td>18.05.02</td>
      <td>To Our Daughter</td>
      <td>Kylie Jenner</td>
      <td>22</td>
      <td>2018-02-04T20:27:38.000Z</td>
      <td>Kylie Jenner|"Kylie"|"Travis Scott"|"Baby"|"An...</td>
      <td>20921796</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/BhIEIO0vaBE/default.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>Directed by Tyler Ross @wttyler\nMusic by Jaco...</td>
    </tr>
    <tr>
      <th>6145</th>
      <td>9v_rtaye2yY</td>
      <td>17.14.12</td>
      <td>Migos, Nicki Minaj, Cardi B - MotorSport (Offi...</td>
      <td>MigosVEVO</td>
      <td>10</td>
      <td>2017-12-08T02:12:48.000Z</td>
      <td>Migos|"Cardi B"|"Cardi"|"Nicki Minaj"|"Nicki"|...</td>
      <td>20136000</td>
      <td>514355</td>
      <td>27521</td>
      <td>57566</td>
      <td>https://i.ytimg.com/vi/9v_rtaye2yY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Listen to MotorSport (feat. Nicki Minaj &amp; Card...</td>
    </tr>
    <tr>
      <th>24156</th>
      <td>QwievZ1Tx-8</td>
      <td>18.17.03</td>
      <td>Marvel Studios' Avengers: Infinity War - Offic...</td>
      <td>Marvel Entertainment</td>
      <td>24</td>
      <td>2018-03-16T13:02:41.000Z</td>
      <td>marvel|"comics"|"comic books"|"nerd"|"geek"|"s...</td>
      <td>19716689</td>
      <td>975715</td>
      <td>9118</td>
      <td>127045</td>
      <td>https://i.ytimg.com/vi/QwievZ1Tx-8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>In theaters April 27. Get your tickets now: ht...</td>
    </tr>
    <tr>
      <th>30752</th>
      <td>rRr1qiJRsXk</td>
      <td>18.25.04</td>
      <td>Sanju | Official Teaser | Ranbir Kapoor | Rajk...</td>
      <td>FoxStarHindi</td>
      <td>24</td>
      <td>2018-04-24T07:58:08.000Z</td>
      <td>Sanju Teaser|"Official Teaser"|"Sanju Official...</td>
      <td>18639195</td>
      <td>511753</td>
      <td>15606</td>
      <td>32435</td>
      <td>https://i.ytimg.com/vi/rRr1qiJRsXk/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Few lives in our times are as dramatic and eni...</td>
    </tr>
    <tr>
      <th>5832</th>
      <td>rRzxEiBLQCA</td>
      <td>17.13.12</td>
      <td>TWICE Heart Shaker M/V</td>
      <td>jypentertainment</td>
      <td>10</td>
      <td>2017-12-11T08:59:59.000Z</td>
      <td>TWICE Heart Shaker|"TWICE 하트셰이커"|"트와이스 Heart S...</td>
      <td>18195959</td>
      <td>754791</td>
      <td>65326</td>
      <td>127305</td>
      <td>https://i.ytimg.com/vi/rRzxEiBLQCA/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>TWICE(트와이스) Heart Shaker M/V\n\nThe 1st Album ...</td>
    </tr>
    <tr>
      <th>5001</th>
      <td>vn9mMeWcgoM</td>
      <td>17.09.12</td>
      <td>Jurassic World: Fallen Kingdom - Official Trai...</td>
      <td>Universal Pictures</td>
      <td>24</td>
      <td>2017-12-08T01:44:25.000Z</td>
      <td>Jurassic World|"Fallen Kingdom"|"Jurassic Park...</td>
      <td>18184886</td>
      <td>399200</td>
      <td>17473</td>
      <td>58902</td>
      <td>https://i.ytimg.com/vi/vn9mMeWcgoM/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Jurassic World: Fallen Kingdom\nIn Theaters Ju...</td>
    </tr>
    <tr>
      <th>32</th>
      <td>n1WpP7iowLc</td>
      <td>17.14.11</td>
      <td>Eminem - Walk On Water (Audio) ft. Beyoncé</td>
      <td>EminemVEVO</td>
      <td>10</td>
      <td>2017-11-10T17:00:03.000Z</td>
      <td>Eminem|"Walk"|"On"|"Water"|"Aftermath/Shady/In...</td>
      <td>17158531</td>
      <td>787419</td>
      <td>43420</td>
      <td>125882</td>
      <td>https://i.ytimg.com/vi/n1WpP7iowLc/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Eminem's new track Walk on Water ft. Beyoncé i...</td>
    </tr>
    <tr>
      <th>39149</th>
      <td>J2HytHu5VBI</td>
      <td>18.06.06</td>
      <td>we broke up</td>
      <td>David Dobrik</td>
      <td>22</td>
      <td>2018-06-05T04:54:35.000Z</td>
      <td>lizzza|"lizza"|"liza"|"koshy"|"david"|"dobrik"...</td>
      <td>16884972</td>
      <td>1366736</td>
      <td>59930</td>
      <td>237907</td>
      <td>https://i.ytimg.com/vi/J2HytHu5VBI/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Sorry we didn't let you know sooner... we want...</td>
    </tr>
    <tr>
      <th>29951</th>
      <td>ffxKSjUwKdU</td>
      <td>18.21.04</td>
      <td>Ariana Grande - No Tears Left To Cry</td>
      <td>ArianaGrandeVevo</td>
      <td>10</td>
      <td>2018-04-20T04:00:03.000Z</td>
      <td>Ariana|"Grande"|"No"|"Tears"|"Left"|"To"|"Cry"...</td>
      <td>15873034</td>
      <td>1386616</td>
      <td>40714</td>
      <td>141630</td>
      <td>https://i.ytimg.com/vi/ffxKSjUwKdU/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>No Tears Left To Cry (Official Video)\nSong Av...</td>
    </tr>
    <tr>
      <th>35349</th>
      <td>yDiXQl7grPQ</td>
      <td>18.18.05</td>
      <td>Do You Hear Yanny or Laurel? (SOLVED with SCIE...</td>
      <td>AsapSCIENCE</td>
      <td>28</td>
      <td>2018-05-16T18:16:26.000Z</td>
      <td>AsapSCIENCE|"audio illusion"|"yanny"|"laurel"|...</td>
      <td>15006579</td>
      <td>278743</td>
      <td>13599</td>
      <td>89194</td>
      <td>https://i.ytimg.com/vi/yDiXQl7grPQ/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Yanny vs. Laurel audio illusion solved! PHEW F...</td>
    </tr>
    <tr>
      <th>23362</th>
      <td>tCXGJQYZ9JA</td>
      <td>18.13.03</td>
      <td>Taylor Swift - Delicate</td>
      <td>TaylorSwiftVEVO</td>
      <td>10</td>
      <td>2018-03-12T01:15:10.000Z</td>
      <td>Taylor Swift|"Delicate"|"Big"|"Machine"|"Recor...</td>
      <td>14820746</td>
      <td>983693</td>
      <td>44254</td>
      <td>97504</td>
      <td>https://i.ytimg.com/vi/tCXGJQYZ9JA/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Music video by Taylor Swift performing Delicat...</td>
    </tr>
    <tr>
      <th>23797</th>
      <td>sS0LCjOiIhc</td>
      <td>18.15.03</td>
      <td>GOT7 Look M/V</td>
      <td>jypentertainment</td>
      <td>10</td>
      <td>2018-03-12T09:00:02.000Z</td>
      <td>JYP Entertainment|"JYP"|"GOT7"|"갓세븐"|"GOT7 JB"...</td>
      <td>14755537</td>
      <td>858708</td>
      <td>8024</td>
      <td>150036</td>
      <td>https://i.ytimg.com/vi/sS0LCjOiIhc/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>GOT7(갓세븐) Look M/V\n\nFind GOT7 Eyes On You on...</td>
    </tr>
    <tr>
      <th>19376</th>
      <td>V5cOvyDpWfM</td>
      <td>18.21.02</td>
      <td>Fergie Performs The U.S. National Anthem / 201...</td>
      <td>MLG Highlights</td>
      <td>17</td>
      <td>2018-02-19T01:37:11.000Z</td>
      <td>mlg highlights|"mlg"|"basketball"|"highlights"...</td>
      <td>14647590</td>
      <td>32892</td>
      <td>117128</td>
      <td>44404</td>
      <td>https://i.ytimg.com/vi/V5cOvyDpWfM/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>🏀Fergie Performs The U.S. National Anthem / 20...</td>
    </tr>
    <tr>
      <th>11600</th>
      <td>dfnCAmr569k</td>
      <td>18.13.01</td>
      <td>Taylor Swift - End Game ft. Ed Sheeran, Future</td>
      <td>TaylorSwiftVEVO</td>
      <td>10</td>
      <td>2018-01-12T05:00:01.000Z</td>
      <td>Taylor|"Swift"|"End"|"Game"|"Big"|"Machine"|"Pop"</td>
      <td>14089954</td>
      <td>1065777</td>
      <td>47839</td>
      <td>96579</td>
      <td>https://i.ytimg.com/vi/dfnCAmr569k/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Music video by Taylor Swift performing End Gam...</td>
    </tr>
    <tr>
      <th>2201</th>
      <td>kTlv5_Bs8aw</td>
      <td>17.25.11</td>
      <td>BTS (방탄소년단) 'MIC Drop (Steve Aoki Remix)' Offi...</td>
      <td>ibighit</td>
      <td>10</td>
      <td>2017-11-24T09:00:02.000Z</td>
      <td>BIGHIT|"빅히트"|"방탄소년단"|"BTS"|"BANGTAN"|"방탄"</td>
      <td>13945717</td>
      <td>2055137</td>
      <td>23888</td>
      <td>395562</td>
      <td>https://i.ytimg.com/vi/kTlv5_Bs8aw/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>BTS (방탄소년단) 'MIC Drop (Steve Aoki Remix)' Offi...</td>
    </tr>
    <tr>
      <th>16825</th>
      <td>_5d-sQ7Fh5M</td>
      <td>18.08.02</td>
      <td>LOGAN PAUL IS BACK!</td>
      <td>Logan Paul Vlogs</td>
      <td>24</td>
      <td>2018-02-04T22:02:27.000Z</td>
      <td>logan paul vlog|"logan paul"|"logan"|"paul"|"o...</td>
      <td>13754992</td>
      <td>1207457</td>
      <td>280675</td>
      <td>432534</td>
      <td>https://i.ytimg.com/vi/_5d-sQ7Fh5M/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Do It Different. Be a Maverick ► https://ShopL...</td>
    </tr>
    <tr>
      <th>10000</th>
      <td>QwZT7T-TXT0</td>
      <td>18.03.01</td>
      <td>So Sorry.</td>
      <td>Logan Paul Vlogs</td>
      <td>24</td>
      <td>2018-01-02T16:42:21.000Z</td>
      <td>logan paul vlog|"logan paul"|"logan"|"paul"|"o...</td>
      <td>13305605</td>
      <td>835378</td>
      <td>629120</td>
      <td>733373</td>
      <td>https://i.ytimg.com/vi/QwZT7T-TXT0/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>31297</th>
      <td>JqfuKsoEEms</td>
      <td>18.27.04</td>
      <td>Hotel Artemis | Official Trailer [HD] | Global...</td>
      <td>Global Road Entertainment</td>
      <td>24</td>
      <td>2018-04-16T12:59:59.000Z</td>
      <td>Global Road|"Global Road Entertainment"|"Movie...</td>
      <td>12952979</td>
      <td>5149</td>
      <td>439</td>
      <td>553</td>
      <td>https://i.ytimg.com/vi/JqfuKsoEEms/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>In HOTEL ARTEMIS, set in riot-torn, near-futur...</td>
    </tr>
    <tr>
      <th>28598</th>
      <td>hYirFqEc8Tg</td>
      <td>18.14.04</td>
      <td>Crossbow Trick Shots | Dude Perfect</td>
      <td>Dude Perfect</td>
      <td>17</td>
      <td>2018-04-09T21:55:11.000Z</td>
      <td>dude perfect|"dude perfect stereotypes"|"dude ...</td>
      <td>12941382</td>
      <td>377740</td>
      <td>7891</td>
      <td>26634</td>
      <td>https://i.ytimg.com/vi/hYirFqEc8Tg/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>It's crossbow time!\nSpecial thanks to Hearths...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>5490</th>
      <td>r3d2alzgjKc</td>
      <td>17.11.12</td>
      <td>exixe clock in action</td>
      <td>dekuNukem</td>
      <td>28</td>
      <td>2017-12-04T14:43:58.000Z</td>
      <td>STM32|"exixe"|"nixie tube"|"nixie"|"hardware"|...</td>
      <td>1425</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/r3d2alzgjKc/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>https://github.com/dekuNukem/exixe\nhttps://gi...</td>
    </tr>
    <tr>
      <th>6493</th>
      <td>P4VipvC54W4</td>
      <td>17.16.12</td>
      <td>coin cell challenge</td>
      <td>Michael Rigsby</td>
      <td>22</td>
      <td>2017-12-06T00:56:56.000Z</td>
      <td>[none]</td>
      <td>1415</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/P4VipvC54W4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Go to hackaday.io and search for coin challeng...</td>
    </tr>
    <tr>
      <th>6587</th>
      <td>OmM425PFd3Y</td>
      <td>17.16.12</td>
      <td>How Noah Galvin Makes Evan Hansen His Own</td>
      <td>BUILD Series</td>
      <td>24</td>
      <td>2017-12-12T22:51:37.000Z</td>
      <td>AOL Advertising|"BUILDseriesNYC"|"AOL Inc"|"AO...</td>
      <td>1402</td>
      <td>20</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/OmM425PFd3Y/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Noah Galvin, currently starring as the title r...</td>
    </tr>
    <tr>
      <th>935</th>
      <td>7xhxjcejONk</td>
      <td>17.18.11</td>
      <td>Star Wars &amp; littleBits Droid Inventor Kit: Mov...</td>
      <td>littleBits Electronics</td>
      <td>28</td>
      <td>2017-11-15T16:18:17.000Z</td>
      <td>littleBits|"starwars"|"inventorswanted"|"droid...</td>
      <td>1387</td>
      <td>15</td>
      <td>1</td>
      <td>1</td>
      <td>https://i.ytimg.com/vi/7xhxjcejONk/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>A kid inventor movement is afoot, with the Dro...</td>
    </tr>
    <tr>
      <th>6822</th>
      <td>plnzNgtvvJo</td>
      <td>17.18.12</td>
      <td>You'll Shoot Your Eye Out Performance | A CHRI...</td>
      <td>FOX</td>
      <td>24</td>
      <td>2017-12-18T04:03:53.000Z</td>
      <td>a christmas story|"christmas"|"holidays"|"gift...</td>
      <td>1386</td>
      <td>67</td>
      <td>20</td>
      <td>20</td>
      <td>https://i.ytimg.com/vi/plnzNgtvvJo/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Miss Shields tells Ralphie the truth about his...</td>
    </tr>
    <tr>
      <th>3354</th>
      <td>0devsSCkYRY</td>
      <td>17.30.11</td>
      <td>The Algorithm That Will Keep You Buying On Cyb...</td>
      <td>NBC News</td>
      <td>25</td>
      <td>2017-11-27T14:39:25.000Z</td>
      <td>nbc news|"nbc"|"news"|"news channel"|"news sta...</td>
      <td>1381</td>
      <td>35</td>
      <td>6</td>
      <td>4</td>
      <td>https://i.ytimg.com/vi/0devsSCkYRY/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Amazon’s item-to-item collaborative filtering ...</td>
    </tr>
    <tr>
      <th>536</th>
      <td>KLZl_sxSN_g</td>
      <td>17.16.11</td>
      <td>WWSB Channel 7:   Sarasota Police stepping up ...</td>
      <td>Sarasota Police Department</td>
      <td>25</td>
      <td>2017-11-08T19:23:52.000Z</td>
      <td>sarasota|"sarasota police"|"city of sarasota"|...</td>
      <td>1338</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/KLZl_sxSN_g/default.jpg</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>SARASOTA, FL (WWSB) - The Florida Department o...</td>
    </tr>
    <tr>
      <th>3929</th>
      <td>BGtsTNCMrQI</td>
      <td>17.03.12</td>
      <td>Test footage of my raspberry pi camera in the ...</td>
      <td>Facelesstech</td>
      <td>20</td>
      <td>2017-11-25T19:26:31.000Z</td>
      <td>raspbery pi|"pi zero"|"pygame"|"ADS1115"|"rasp...</td>
      <td>1237</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>https://i.ytimg.com/vi/BGtsTNCMrQI/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Test footage of my raspberry pi camera in the ...</td>
    </tr>
    <tr>
      <th>4718</th>
      <td>I_puTos3yVs</td>
      <td>17.07.12</td>
      <td>After the Show Show: National Cookie Day</td>
      <td>Fox News</td>
      <td>25</td>
      <td>2017-12-04T15:59:39.000Z</td>
      <td>Fox Friends|"After Show"|"On Air"|"Primary Opi...</td>
      <td>1217</td>
      <td>31</td>
      <td>4</td>
      <td>49</td>
      <td>https://i.ytimg.com/vi/I_puTos3yVs/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Mrs Fields Cookies make a surprise visit on set.</td>
    </tr>
    <tr>
      <th>15886</th>
      <td>3rhw4KgcvFM</td>
      <td>18.03.02</td>
      <td>First Responders Arrive To The Collapsed Floor...</td>
      <td>9-1-1 on FOX</td>
      <td>24</td>
      <td>2018-02-01T02:00:20.000Z</td>
      <td>9-1-1|"first responders"|"police"|"firefighter...</td>
      <td>1172</td>
      <td>12</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/3rhw4KgcvFM/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>First responders arrive to a collapsed floor d...</td>
    </tr>
    <tr>
      <th>14735</th>
      <td>mWaY32HWjKE</td>
      <td>18.28.01</td>
      <td>QB Luke Falk: Need to show you're a fearless p...</td>
      <td>Cleveland Browns</td>
      <td>17</td>
      <td>2018-01-24T18:00:09.000Z</td>
      <td>Cleveland Browns|"NFL"</td>
      <td>1164</td>
      <td>11</td>
      <td>1</td>
      <td>4</td>
      <td>https://i.ytimg.com/vi/mWaY32HWjKE/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>ClevelandBrowns.com caught up with Washington ...</td>
    </tr>
    <tr>
      <th>18843</th>
      <td>lCT0OaVqIQE</td>
      <td>18.18.02</td>
      <td>Jeffrey Tambor Fired From 'Transparent' Follow...</td>
      <td>CBS Los Angeles</td>
      <td>25</td>
      <td>2018-02-16T02:26:02.000Z</td>
      <td>CBS 2 News Mid-day|"jeffrey tambor"|"sexual mi...</td>
      <td>1143</td>
      <td>3</td>
      <td>15</td>
      <td>4</td>
      <td>https://i.ytimg.com/vi/lCT0OaVqIQE/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Jeffrey Tambor's firing comes after a transgen...</td>
    </tr>
    <tr>
      <th>541</th>
      <td>QKwgif8OW1w</td>
      <td>17.16.11</td>
      <td>Vostok Brompton Beach Ride</td>
      <td>Vostok.bike</td>
      <td>19</td>
      <td>2017-10-21T15:12:53.000Z</td>
      <td>Vostok.bike|"Brompton Bicycle"|"Brompton Alfin...</td>
      <td>1118</td>
      <td>6</td>
      <td>0</td>
      <td>2</td>
      <td>https://i.ytimg.com/vi/QKwgif8OW1w/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Early morning drone footage of a beach ride in...</td>
    </tr>
    <tr>
      <th>4933</th>
      <td>GF_0i9WxA_s</td>
      <td>17.08.12</td>
      <td>Obama Answers Akkai Padmashali (Transgender Ac...</td>
      <td>taalk com</td>
      <td>26</td>
      <td>2017-12-04T10:46:47.000Z</td>
      <td>gender|"Transgender"|"equality"|"caste system"...</td>
      <td>1107</td>
      <td>19</td>
      <td>2</td>
      <td>4</td>
      <td>https://i.ytimg.com/vi/GF_0i9WxA_s/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Akkai Padmashali, a noted voice in the Indian ...</td>
    </tr>
    <tr>
      <th>1917</th>
      <td>2a52cBN9qOA</td>
      <td>17.23.11</td>
      <td>Additional Remains Of Miami Gardens Soldier Re...</td>
      <td>CBS Miami</td>
      <td>25</td>
      <td>2017-11-21T17:26:32.000Z</td>
      <td>CBS 4 News Morning|"La David Johnson"|"Joan Mu...</td>
      <td>1095</td>
      <td>8</td>
      <td>2</td>
      <td>13</td>
      <td>https://i.ytimg.com/vi/2a52cBN9qOA/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Sgt. La David Johnson and three others were ki...</td>
    </tr>
    <tr>
      <th>6344</th>
      <td>B7B6x2bHcUs</td>
      <td>17.15.12</td>
      <td>Get to know Doug Jones, Alabama's newest Senator</td>
      <td>Newsy</td>
      <td>25</td>
      <td>2017-12-13T03:58:29.000Z</td>
      <td>former federal prosecutor doug jones|"former j...</td>
      <td>1087</td>
      <td>38</td>
      <td>12</td>
      <td>18</td>
      <td>https://i.ytimg.com/vi/B7B6x2bHcUs/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>The career prosecutor pulled off an upset on T...</td>
    </tr>
    <tr>
      <th>10704</th>
      <td>Wwyxaow1wWg</td>
      <td>18.06.01</td>
      <td>Inventing The Wheel</td>
      <td>J Gasser</td>
      <td>24</td>
      <td>2017-11-08T22:27:53.000Z</td>
      <td>[none]</td>
      <td>987</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/Wwyxaow1wWg/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>How The Wheel Was Really Invented.</td>
    </tr>
    <tr>
      <th>13145</th>
      <td>jiP82WVx6mM</td>
      <td>18.20.01</td>
      <td>The author of the 5:2 diet explains why eating...</td>
      <td>Business Insider UK</td>
      <td>28</td>
      <td>2018-01-17T14:23:32.000Z</td>
      <td>Business|"Insider"|"BI"|"UK"|"Europe"</td>
      <td>983</td>
      <td>15</td>
      <td>1</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/jiP82WVx6mM/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Michael Mosley, author of the 5:2 diet and the...</td>
    </tr>
    <tr>
      <th>42</th>
      <td>NZFhMSgbKKM</td>
      <td>17.14.11</td>
      <td>Dennis Smith Jr. and LeBron James go back and ...</td>
      <td>Ben Rohrbach</td>
      <td>17</td>
      <td>2017-11-13T15:11:00.000Z</td>
      <td>[none]</td>
      <td>945</td>
      <td>7</td>
      <td>5</td>
      <td>8</td>
      <td>https://i.ytimg.com/vi/NZFhMSgbKKM/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10902</th>
      <td>s_FAjI51LPU</td>
      <td>18.07.01</td>
      <td>Gas Mask Scene | Kong: Skull Island (2017)</td>
      <td>Adam Whitley</td>
      <td>1</td>
      <td>2017-08-14T20:33:41.000Z</td>
      <td>gas mask samurai|"jordan vogt-roberts"|"kong s...</td>
      <td>943</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/s_FAjI51LPU/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Kong: Skull Island DVD and Blu-ray release dat...</td>
    </tr>
    <tr>
      <th>1114</th>
      <td>g3VgrgV3kFk</td>
      <td>17.19.11</td>
      <td>John Thrasher: Jimbo's here forever</td>
      <td>Single Shot</td>
      <td>17</td>
      <td>2017-11-16T22:50:00.000Z</td>
      <td>fsu|"florida state"|"Seminoles"|"Seminole"|"no...</td>
      <td>920</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>https://i.ytimg.com/vi/g3VgrgV3kFk/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>In an interview with Tia Mitchell of the Flori...</td>
    </tr>
    <tr>
      <th>11710</th>
      <td>TKMXw1YI5S4</td>
      <td>18.13.01</td>
      <td>UR EEOC Complainants Press Conference (5pm Jan...</td>
      <td>University of Rochester EEOC Complainants</td>
      <td>22</td>
      <td>2018-01-11T22:55:37.000Z</td>
      <td>University of Rochester|"UR sexual harassment ...</td>
      <td>884</td>
      <td>11</td>
      <td>5</td>
      <td>2</td>
      <td>https://i.ytimg.com/vi/TKMXw1YI5S4/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>University of Rochester EEOC Complainants, rep...</td>
    </tr>
    <tr>
      <th>12961</th>
      <td>tKX8nUCSBjM</td>
      <td>18.19.01</td>
      <td>Bannon Arrives to Testify on Capitol Hill</td>
      <td>Associated Press</td>
      <td>25</td>
      <td>2018-01-16T15:16:11.000Z</td>
      <td>united states|"north america"|"donald trump"|"...</td>
      <td>810</td>
      <td>9</td>
      <td>5</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/tKX8nUCSBjM/default.jpg</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>Steven Bannon, a former aide to US President D...</td>
    </tr>
    <tr>
      <th>14816</th>
      <td>S_HixQBiVH0</td>
      <td>18.29.01</td>
      <td>John Legend And Tony Bennett Sing 'New York, N...</td>
      <td>CBS</td>
      <td>24</td>
      <td>2018-01-29T02:33:04.000Z</td>
      <td>grammy|"grammys"|"grammy awards"|"grammy award...</td>
      <td>798</td>
      <td>45</td>
      <td>4</td>
      <td>6</td>
      <td>https://i.ytimg.com/vi/S_HixQBiVH0/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>The duo does an impromptu duet before announci...</td>
    </tr>
    <tr>
      <th>11103</th>
      <td>JNv4w6DFoYs</td>
      <td>18.08.01</td>
      <td>OjO Commuter Scooter®- Light Electric Vehicle ...</td>
      <td>OjO Commuter Scooter by OjO Electric</td>
      <td>19</td>
      <td>2017-11-10T19:18:46.000Z</td>
      <td>OjO|"OjO Electric"|"OjO Commuter Scooter"|"Ele...</td>
      <td>789</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/JNv4w6DFoYs/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>OjO Commuter Scooter® is the ultimate two-whee...</td>
    </tr>
    <tr>
      <th>160</th>
      <td>qg0GdM60syI</td>
      <td>17.14.11</td>
      <td>Huffy Metaloid Bicycle Commercial 1997</td>
      <td>90s Commercials</td>
      <td>27</td>
      <td>2017-03-31T21:46:53.000Z</td>
      <td>90s commercials|"Huffy"</td>
      <td>773</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/qg0GdM60syI/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Anyone have one of those?</td>
    </tr>
    <tr>
      <th>12716</th>
      <td>zeQaJGkFyqQ</td>
      <td>18.18.01</td>
      <td>Raw: 3 South Carolina Deputies, 1 Officer Shot</td>
      <td>Associated Press</td>
      <td>25</td>
      <td>2018-01-16T12:16:44.000Z</td>
      <td>news|"associated press"|"ap"|"ap online"|"asso...</td>
      <td>748</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/zeQaJGkFyqQ/default.jpg</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>Three deputies and one police officer were sho...</td>
    </tr>
    <tr>
      <th>546</th>
      <td>#NAME?</td>
      <td>17.16.11</td>
      <td>Coach Taggart Monday Presser Ahead of Arizona</td>
      <td>GoDucksdotcom</td>
      <td>17</td>
      <td>2017-11-13T20:41:45.000Z</td>
      <td>Oregon|"Ducks"|"college athletics"|"college fo...</td>
      <td>687</td>
      <td>10</td>
      <td>2</td>
      <td>5</td>
      <td>https://i.ytimg.com/vi/-JVITToppE0/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Coach Taggart addresses the media ahead of the...</td>
    </tr>
    <tr>
      <th>14531</th>
      <td>dQMZLXaa1L8</td>
      <td>18.27.01</td>
      <td>Artwork Forge</td>
      <td>Palo Alto Online</td>
      <td>17</td>
      <td>2018-01-10T23:53:56.000Z</td>
      <td>[none]</td>
      <td>658</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>https://i.ytimg.com/vi/dQMZLXaa1L8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Artwork Forge II - an art installation created...</td>
    </tr>
    <tr>
      <th>14335</th>
      <td>y6KYFcta4SE</td>
      <td>18.26.01</td>
      <td>1 dead, others injured after Ky. school shooting</td>
      <td>Newsy</td>
      <td>25</td>
      <td>2018-01-23T15:30:01.000Z</td>
      <td>shooting|"kentucky"|"breaking news"|"u.s. news...</td>
      <td>549</td>
      <td>9</td>
      <td>0</td>
      <td>5</td>
      <td>https://i.ytimg.com/vi/y6KYFcta4SE/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Kentucky Gov. Matt Bevin confirmed there was a...</td>
    </tr>
  </tbody>
</table>
<p>6455 rows × 16 columns</p>
</div>



We are now going to analyze the top 10 most viewed YouTube Videos in the US and we're going to see what common group(s) of generes have put these videos in a very high percentile in terms of viewership.


```python
#Top 10 Most Watched Videos from the 2017-2018 Period
Videos_In_US_Top_10 = Videos_In_US.nlargest(10, "views")
```


```python
Videos_In_US_Top_10.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>video_id</th>
      <th>trending_date</th>
      <th>title</th>
      <th>channel_title</th>
      <th>category_id</th>
      <th>publish_time</th>
      <th>tags</th>
      <th>views</th>
      <th>likes</th>
      <th>dislikes</th>
      <th>comment_count</th>
      <th>thumbnail_link</th>
      <th>comments_disabled</th>
      <th>ratings_disabled</th>
      <th>video_error_or_removed</th>
      <th>description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>23824</th>
      <td>#NAME?</td>
      <td>18.15.03</td>
      <td>Maluma - El Préstamo (Official Video)</td>
      <td>MalumaVEVO</td>
      <td>10</td>
      <td>2018-03-09T11:00:01.000Z</td>
      <td>Maluma Music|"Maluma Official Video"|"Maluma V...</td>
      <td>48431654</td>
      <td>609101</td>
      <td>52259</td>
      <td>29172</td>
      <td>https://i.ytimg.com/vi/-BQJo3vK8O8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>Maluma - El Prestamo (Official Music Video)\nE...</td>
    </tr>
    <tr>
      <th>35550</th>
      <td>7C2z4GqqS5E</td>
      <td>18.19.05</td>
      <td>BTS (방탄소년단) 'FAKE LOVE' Official MV</td>
      <td>ibighit</td>
      <td>10</td>
      <td>2018-05-18T09:00:02.000Z</td>
      <td>BIGHIT|"빅히트"|"방탄소년단"|"BTS"|"BANGTAN"|"방탄"</td>
      <td>39349927</td>
      <td>3880071</td>
      <td>72707</td>
      <td>692305</td>
      <td>https://i.ytimg.com/vi/7C2z4GqqS5E/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>BTS (방탄소년단) 'FAKE LOVE' Official MVDirector : ...</td>
    </tr>
    <tr>
      <th>28605</th>
      <td>i0p1bmr0EmE</td>
      <td>18.14.04</td>
      <td>TWICE What is Love? M/V</td>
      <td>jypentertainment</td>
      <td>10</td>
      <td>2018-04-09T08:59:51.000Z</td>
      <td>TWICE What is Love|"TWICE What is Love?"|"TWIC...</td>
      <td>38873543</td>
      <td>1111592</td>
      <td>96407</td>
      <td>206632</td>
      <td>https://i.ytimg.com/vi/i0p1bmr0EmE/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>TWICE(트와이스) What is Love? M/V\n\nSpotify https...</td>
    </tr>
    <tr>
      <th>3200</th>
      <td>6ZfuNTqbHE8</td>
      <td>17.30.11</td>
      <td>Marvel Studios' Avengers: Infinity War Officia...</td>
      <td>Marvel Entertainment</td>
      <td>24</td>
      <td>2017-11-29T13:26:24.000Z</td>
      <td>marvel|"comics"|"comic books"|"nerdy"|"geeky"|...</td>
      <td>37736281</td>
      <td>1735895</td>
      <td>21969</td>
      <td>241237</td>
      <td>https://i.ytimg.com/vi/6ZfuNTqbHE8/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>There was an idea… Avengers: Infinity War. In ...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>2Vv-BfVoq4g</td>
      <td>17.14.11</td>
      <td>Ed Sheeran - Perfect (Official Music Video)</td>
      <td>Ed Sheeran</td>
      <td>10</td>
      <td>2017-11-09T11:04:14.000Z</td>
      <td>edsheeran|"ed sheeran"|"acoustic"|"live"|"cove...</td>
      <td>33523622</td>
      <td>1634124</td>
      <td>21082</td>
      <td>85067</td>
      <td>https://i.ytimg.com/vi/2Vv-BfVoq4g/default.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>🎧: https://ad.gt/yt-perfect\n💰: https://atlant...</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Plot of the Number of Views from the Top 10 Most Watched Videos from the 2017-2018 Period
plt.figure(figsize=(13, 7), dpi=200)
plt.bar(Videos_In_US_Top_10["title"],Videos_In_US_Top_10["views"])
plt.xticks(rotation=90)
plt.ylabel("views")
plt.title("Amount of Views for the Top 10 YouTube Videos")
plt.show()

```


![png](output_8_0.png)


From the bar graph from above, we can see that the top 10 most viewed videos in the US tend to be in the genres of music videos and superhero films (for example, "Marvel Studios' Avengers: Infinity War Official Trailer" and "VENOM - Official Trailer(HD)"). The only videos that seem to be the exception of the rule in this trend would be "YouTube Rewind: The Shape of 2017|#YouTubeRewind" and "Sanju|Official|Trailer|Ranbir Kapoor|Rajkumar Hirani|Releasing on 29th June" since Youtube's 2017 Rewind is simply a compulation of popular YouTube channels/videos from that year and the Sanju film is a biographical film about the actor Sanjay Dutt. 


```python
#Observing the differences of the number of likes, dislikes, and comments of trending videos in the US
number_of_likes = sns.jointplot(x = "views", y = "likes", data = Videos_In_US, kind = "reg")
number_of_likes.annotate(stats.pearsonr)
number_of_comments = sns.jointplot(x = "views", y = "comment_count", data = Videos_In_US, kind = "reg")
number_of_comments.annotate(stats.pearsonr)
number_of_dislikes = sns.jointplot(x = "views", y = "dislikes", data = Videos_In_US, kind = "reg")
number_of_dislikes.annotate(stats.pearsonr)
plt.figure(figsize = (16, 9), dpi = 200)
plt.show()
```

    c:\users\ugoch\appdata\local\programs\python\python37-32\lib\site-packages\seaborn\axisgrid.py:1847: UserWarning: JointGrid annotation is deprecated and will be removed in a future release.
      warnings.warn(UserWarning(msg))
    


![png](output_10_1.png)



![png](output_10_2.png)



![png](output_10_3.png)



    <Figure size 3200x1800 with 0 Axes>


For the three graphs, we can see that the one thing that they have in common is that they all have fairly weak positive linear relatioships since a fair amount of points tend to be scattered away from the line of best fit, but a large portion of the points are very close to the line of best fit. However, the differences that I have seen in each graph would be that the graph that focuses on the number of likes in each trending video shows a trend in which as the videos increase in the amount of views that they have, there's an increase in the amount of likes that it will have (we really start to see this consistent level of growth around 5,000,000 views, reaches it's peak at 40,000,000 views with 4,000,000 likes, and then declines right after that); the graph with the number of comments has a similar style of growth as the graph with the number of likes, but the difference between the two is that the graph with the number of comments has a much larger dispersion of data points from the best line of fit at around 2,000,000 views and reaches it's max comment count at 15,000,000 views with around 720,000 comments; the graph with the number of dislikes is the most different out of the three graphs in which it reaches it's maximum peak on its perspective y axis very early at 15,000,000 views with 600,000 dislikes and after that point, there's a consistent increase in dislikes as the views increase, but the majority of those dislikes are under 100,000 dislikes. Based on these observations, we can safely conclude that as the more popular a video gets in viewership, the more likes and commentary that the video will receive; and as the least popular a video gets in viewership, the more dislikes that the video will receive.
